export default function App(){return <div>Na Contramão Planejados</div>}
